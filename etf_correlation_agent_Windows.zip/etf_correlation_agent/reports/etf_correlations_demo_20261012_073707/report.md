# Informe de correlaciones y relaciones entre ETFs

* **Modo**: demo (datos sintéticos)
* **Generado**: 2026-10-12T07:37:07
* **ETFs analizados** (22): SPY, QQQ, IWM, EFA, EEM, TLT, IEF, TIP, SGOV, LQD, HYG, UUP, GLD, USO, DBC, XLK, XLF, XLE, XLU, XLP, SOXX, DRAM
* **Periodo de datos**: 2015-01-01 → 2026-10-12 (3073 sesiones, 3072 retornos)
* **Ventanas**: max (Histórico completo), ytd (Año en curso (YTD)), 3m (Últimos 3 meses), 1m (Último mes)

```
SPY (Renta variable (large cap USA)), QQQ (Renta variable (Nasdaq 100)), IWM (Renta variable (small caps USA)), EFA (Renta variable (desarrollados ex-NA)), EEM (Renta variable (emergentes)), TLT (Renta fija (bonos largos USA)), IEF (Renta fija (bonos medios USA)), TIP (Renta fija (protegido de inflación)), SGOV (Letras del Tesoro (cash-like)), LQD (Crédito corporativo (IG)), HYG (Crédito corporativo (HY)), UUP (Divisas (dólar DXY)), GLD (Materias primas (oro)), USO (Materias primas (petróleo)), DBC (Materias primas (cesta diversificada)), XLK (Sector: Tecnología), XLF (Sector: Financiero), XLE (Sector: Energía), XLU (Sector: Utilities (defensivo)), XLP (Sector: Consumo defensivo), SOXX (Semiconductores), DRAM (Semiconductores (memoria))
```

## 0. Evolución comparada

![precios](images/precios_normalizados.png)

## 1. Correlaciones por ventana temporal

### Ventana `max` — Histórico completo

Observaciones utilizadas: **3072** retornos diarios.

**Pearson (lineal)**

![heatmap max pearson](images/heatmap_max_pearson.png)
**Spearman (rangos)**

![heatmap max spearman](images/heatmap_max_spearman.png)

**Top 15 pares más correlacionados (Pearson, max)**

| A | B | corr | abs_corr |
| --- | --- | --- | --- |
| IEF | TIP | 0.655 | 0.655 |
| SPY | XLK | 0.655 | 0.655 |
| SPY | EFA | 0.651 | 0.651 |
| SPY | XLF | 0.597 | 0.597 |
| SPY | EEM | 0.546 | 0.546 |
| EFA | XLK | 0.537 | 0.537 |
| SPY | IWM | 0.517 | 0.517 |
| EFA | XLF | 0.503 | 0.503 |
| TLT | IEF | 0.492 | 0.492 |
| XLK | SOXX | 0.484 | 0.484 |
| EFA | EEM | 0.477 | 0.477 |
| TLT | TIP | 0.476 | 0.476 |
| IEF | LQD | 0.474 | 0.474 |
| SPY | QQQ | 0.471 | 0.471 |
| TIP | LQD | 0.459 | 0.459 |
### Ventana `ytd` — Año en curso (YTD)

Observaciones utilizadas: **203** retornos diarios.

**Pearson (lineal)**

![heatmap ytd pearson](images/heatmap_ytd_pearson.png)
**Spearman (rangos)**

![heatmap ytd spearman](images/heatmap_ytd_spearman.png)

**Top 15 pares más correlacionados (Pearson, ytd)**

| A | B | corr | abs_corr |
| --- | --- | --- | --- |
| SPY | EFA | 0.716 | 0.716 |
| IEF | TIP | 0.704 | 0.704 |
| SPY | XLK | 0.678 | 0.678 |
| SPY | XLF | 0.660 | 0.660 |
| EFA | XLK | 0.633 | 0.633 |
| TLT | IEF | 0.578 | 0.578 |
| EFA | XLF | 0.550 | 0.550 |
| IEF | LQD | 0.541 | 0.541 |
| EFA | EEM | 0.540 | 0.540 |
| SPY | IWM | 0.538 | 0.538 |
| SPY | EEM | 0.537 | 0.537 |
| SPY | QQQ | 0.528 | 0.528 |
| XLK | SOXX | 0.515 | 0.515 |
| EEM | XLK | 0.504 | 0.504 |
| IEF | SGOV | 0.503 | 0.503 |
### Ventana `3m` — Últimos 3 meses

Observaciones utilizadas: **66** retornos diarios.

**Pearson (lineal)**

![heatmap 3m pearson](images/heatmap_3m_pearson.png)
**Spearman (rangos)**

![heatmap 3m spearman](images/heatmap_3m_spearman.png)

**Top 15 pares más correlacionados (Pearson, 3m)**

| A | B | corr | abs_corr |
| --- | --- | --- | --- |
| IEF | TIP | 0.733 | 0.733 |
| SPY | EFA | 0.636 | 0.636 |
| TIP | SGOV | 0.577 | 0.577 |
| EFA | XLK | 0.567 | 0.567 |
| TLT | IEF | 0.565 | 0.565 |
| SPY | XLK | 0.564 | 0.564 |
| IEF | SGOV | 0.545 | 0.545 |
| SPY | XLF | 0.526 | 0.526 |
| TLT | TIP | 0.512 | 0.512 |
| IEF | LQD | 0.497 | 0.497 |
| XLK | SOXX | 0.494 | 0.494 |
| EEM | XLK | 0.489 | 0.489 |
| SPY | IWM | 0.475 | 0.475 |
| UUP | DBC | -0.475 | 0.475 |
| EFA | EEM | 0.455 | 0.455 |
### Ventana `1m` — Último mes

Observaciones utilizadas: **21** retornos diarios.

**Pearson (lineal)**

![heatmap 1m pearson](images/heatmap_1m_pearson.png)
**Spearman (rangos)**

![heatmap 1m spearman](images/heatmap_1m_spearman.png)

**Top 15 pares más correlacionados (Pearson, 1m)**

| A | B | corr | abs_corr |
| --- | --- | --- | --- |
| IEF | TIP | 0.819 | 0.819 |
| TLT | IEF | 0.654 | 0.654 |
| SPY | XLK | 0.649 | 0.649 |
| TLT | TIP | 0.647 | 0.647 |
| TIP | SGOV | 0.641 | 0.641 |
| UUP | DBC | -0.632 | 0.632 |
| IEF | SGOV | 0.614 | 0.614 |
| XLK | DRAM | 0.606 | 0.606 |
| SPY | EFA | 0.595 | 0.595 |
| TLT | XLK | -0.564 | 0.564 |
| GLD | USO | 0.527 | 0.527 |
| TLT | DRAM | -0.493 | 0.493 |
| SPY | SOXX | 0.489 | 0.489 |
| EEM | TLT | -0.489 | 0.489 |
| SPY | IWM | 0.488 | 0.488 |

## 2. Régimen de correlación

La correlación media entre todos los pares del universo muestra cómo se **concentran los movimientos** (sube en crisis, baja en mercados tranquilos).

![rolling avg](images/rolling_corr_media.png)

## 3. Correlación móvil de los pares más relevantes

![rolling pairs](images/rolling_corr_pares.png)

## 4. Relaciones lead-lag (¿quién anticipa a quién?)

Para cada par se busca el rezago (hasta ±10 sesiones) con mayor correlación. Un `best_lag_days > 0` indica que `leader` se mueve **antes** que `follower`.

| leader | follower | best_lag_days | best_lag_signed | best_corr | corr_lag0 | n_obs |
| --- | --- | --- | --- | --- | --- | --- |
| SPY | SOXX | 1 | 1 | 0.147 | 0.431 | 3072 |
| XLF | SOXX | 1 | 1 | 0.130 | 0.266 | 3072 |
| XLF | DRAM | 1 | 1 | 0.125 | 0.156 | 3072 |
| QQQ | SOXX | 1 | 1 | 0.124 | 0.174 | 3072 |
| EFA | SOXX | 1 | 1 | 0.122 | 0.317 | 3072 |
| IWM | DRAM | 1 | 1 | 0.120 | 0.087 | 3072 |
| IWM | SOXX | 1 | 1 | 0.120 | 0.213 | 3072 |
| SPY | DRAM | 1 | 1 | 0.113 | 0.272 | 3072 |
| EEM | SOXX | 1 | 1 | 0.107 | 0.307 | 3072 |
| XLP | SOXX | 1 | 1 | 0.106 | 0.182 | 3072 |
| XLK | SOXX | 1 | 1 | 0.102 | 0.484 | 3072 |
| QQQ | DRAM | 1 | 1 | 0.101 | 0.100 | 3072 |

## 5. Causalidad de Granger

H0: `cause` **no** ayuda a predecir `effect`. Pares con p-value < 0.05 (cuidado: con muchas series aparecerán falsos positivos; valora también la fuerza económica).

**Pares significativos: 80 de 462 tests.**

| cause | effect | best_lag | p_value | significativo |
| --- | --- | --- | --- | --- |
| SPY | SOXX | 1 | 0.000 | True |
| XLF | DRAM | 1 | 0.000 | True |
| XLF | SOXX | 1 | 0.000 | True |
| IWM | DRAM | 1 | 0.000 | True |
| QQQ | SOXX | 1 | 0.000 | True |
| IWM | SOXX | 2 | 0.000 | True |
| EFA | SOXX | 1 | 0.000 | True |
| SPY | DRAM | 1 | 0.000 | True |
| QQQ | DRAM | 1 | 0.000 | True |
| XLP | SOXX | 1 | 0.000 | True |
| XLP | DRAM | 1 | 0.000 | True |
| EEM | SOXX | 1 | 0.000 | True |
| XLU | SOXX | 1 | 0.000 | True |
| EFA | DRAM | 1 | 0.000 | True |
| XLK | SOXX | 1 | 0.000 | True |

## 6. Cointegración (relaciones de largo plazo)

Pares cointegrados (p < 0.05): **5**. Estos pares comparten una tendencia estocástica común: su spread revierte a la media, lo que permite estrategias de pares. `half_life_days` ≈ días que tarda el spread en corregirse a la mitad; `spread_zscore` mide cuán lejos está ahora.

| A | B | hedge_ratio | coint_pvalue | cointegrada | adf_pvalue_spread | half_life_days | spread_zscore | corr_logprecios |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| XLE | SOXX | 0.622 | 0.006 | True | 0.001 | 68.061 | 0.118 | 0.910 |
| EFA | LQD | 1.421 | 0.014 | True | 0.003 | 85.413 | 1.017 | 0.762 |
| EFA | DBC | 0.450 | 0.026 | True | 0.006 | 104.268 | 2.145 | 0.779 |
| EFA | EEM | 0.435 | 0.030 | True | 0.007 | 86.168 | 0.918 | 0.889 |
| TLT | GLD | 1.214 | 0.033 | True | 0.008 | 100.141 | -0.671 | 0.898 |
| XLK | XLE | 1.208 | 0.072 | False | 0.021 | 105.414 | 1.329 | 0.901 |
| TLT | SGOV | -3.209 | 0.075 | False | 0.022 | 106.742 | -0.248 | -0.964 |
| IEF | XLU | 0.431 | 0.079 | False | 0.023 | 106.519 | -0.850 | 0.957 |
| SGOV | GLD | -0.355 | 0.109 | False | 0.034 | 153.318 | 0.687 | -0.873 |
| LQD | XLK | 0.126 | 0.115 | False | 0.037 | 157.586 | 1.012 | 0.639 |
| IWM | EFA | 0.901 | 0.120 | False | 0.039 | 188.833 | 0.112 | 0.687 |
| HYG | XLU | 0.304 | 0.134 | False | 0.045 | 168.225 | -0.793 | 0.777 |
| IEF | HYG | 0.883 | 0.147 | False | 0.050 | 176.522 | 0.016 | 0.768 |
| SPY | QQQ | 0.865 | 0.165 | False | 0.058 | 125.694 | 2.030 | 0.961 |
| TIP | XLP | 0.313 | 0.178 | False | 0.064 | 133.496 | -0.471 | 0.494 |

## 7. Exposición factorial (betas)

Regresión OLS de cada ETF sobre los factores ['SPY', 'TLT', 'GLD']. El `beta` mide sensibilidad (beta 1 = se mueve igual que el factor).

| etf | alpha_diario | alpha_anualizado_pct | r2 | r2_adj | beta_SPY | beta_TLT | beta_GLD |
| --- | --- | --- | --- | --- | --- | --- | --- |
| QQQ | 0.000 | 7.261 | 0.223 | 0.222 | 0.481 | 0.011 | -0.031 |
| IWM | -0.000 | -5.133 | 0.267 | 0.266 | 0.499 | 0.026 | -0.009 |
| EFA | -0.000 | -2.972 | 0.424 | 0.424 | 0.633 | -0.045 | -0.002 |
| EEM | 0.000 | 1.445 | 0.302 | 0.302 | 0.606 | -0.034 | 0.081 |
| IEF | 0.000 | 0.710 | 0.249 | 0.248 | -0.016 | 0.283 | 0.035 |
| TIP | 0.000 | 2.597 | 0.242 | 0.241 | -0.009 | 0.269 | 0.059 |
| SGOV | 0.000 | 2.905 | 0.093 | 0.092 | 0.003 | 0.016 | 0.002 |
| LQD | 0.000 | 2.151 | 0.146 | 0.145 | 0.092 | 0.241 | 0.026 |
| HYG | -0.000 | -2.019 | 0.142 | 0.141 | 0.247 | 0.066 | 0.038 |
| UUP | 0.000 | 4.523 | 0.060 | 0.059 | -0.082 | -0.004 | -0.173 |
| USO | 0.000 | 9.891 | 0.042 | 0.041 | 0.277 | -0.018 | 0.313 |
| DBC | -0.000 | -0.259 | 0.071 | 0.070 | 0.258 | 0.031 | 0.267 |
| XLK | 0.000 | 3.596 | 0.441 | 0.440 | 0.914 | -0.207 | -0.058 |
| XLF | -0.000 | -9.894 | 0.358 | 0.358 | 0.706 | 0.057 | -0.043 |
| XLE | 0.000 | 3.407 | 0.160 | 0.159 | 0.551 | -0.036 | 0.241 |
| XLU | -0.000 | -4.956 | 0.100 | 0.099 | 0.234 | 0.167 | -0.015 |
| XLP | -0.000 | -1.952 | 0.196 | 0.195 | 0.317 | 0.069 | 0.018 |
| SOXX | 0.000 | 4.273 | 0.189 | 0.188 | 0.881 | -0.176 | -0.029 |
| DRAM | 0.000 | 5.896 | 0.076 | 0.075 | 0.758 | -0.155 | -0.036 |

## 8. Factores latentes (PCA)

Los primeros 5 componentes explican **54.9%** de la varianza total. PC1 suele ser 'el mercado'; los siguientes capturan tipos, materias primas, dólar, etc. Cargas altas (en |·|) = ETF muy ligado a ese factor.

![pca](images/pca_scree.png)

**Varianza explicada**

| componente | fraccion |
| --- | --- |
| PC1 | 0.235 |
| PC2 | 0.136 |
| PC3 | 0.085 |
| PC4 | 0.053 |
| PC5 | 0.040 |

**Cargas (loadings)**

| etf | PC1 | PC2 | PC3 | PC4 | PC5 |
| --- | --- | --- | --- | --- | --- |
| SPY | 0.380 | -0.020 | 0.074 | 0.005 | -0.024 |
| QQQ | 0.253 | 0.028 | 0.114 | -0.274 | -0.154 |
| IWM | 0.271 | 0.026 | 0.137 | -0.266 | -0.082 |
| EFA | 0.336 | -0.015 | 0.034 | -0.055 | -0.051 |
| EEM | 0.306 | 0.016 | -0.135 | 0.050 | 0.135 |
| TLT | -0.116 | 0.374 | 0.025 | 0.080 | 0.043 |
| IEF | -0.077 | 0.471 | 0.081 | 0.078 | -0.082 |
| TIP | -0.057 | 0.472 | -0.065 | 0.047 | -0.053 |
| SGOV | -0.005 | 0.355 | 0.114 | 0.115 | -0.297 |
| LQD | 0.065 | 0.401 | 0.091 | 0.119 | 0.352 |
| HYG | 0.211 | 0.124 | -0.037 | -0.011 | 0.730 |
| UUP | -0.091 | -0.039 | 0.502 | -0.099 | -0.087 |
| GLD | -0.004 | 0.122 | -0.356 | 0.050 | -0.267 |
| USO | 0.105 | 0.057 | -0.381 | -0.067 | -0.174 |
| DBC | 0.135 | 0.068 | -0.480 | -0.041 | 0.016 |
| XLK | 0.324 | -0.096 | 0.108 | 0.251 | -0.049 |
| XLF | 0.308 | 0.059 | 0.130 | -0.133 | -0.002 |
| XLE | 0.221 | 0.054 | -0.270 | -0.107 | -0.119 |
| XLU | 0.154 | 0.216 | 0.185 | -0.103 | -0.177 |
| XLP | 0.239 | 0.114 | 0.102 | -0.193 | -0.111 |
| SOXX | 0.227 | -0.072 | 0.077 | 0.475 | -0.051 |
| DRAM | 0.149 | -0.077 | 0.049 | 0.650 | -0.139 |

## 9. Agrupamiento de ETFs (clustering)

ETFs con comportamientos similares quedan agrupados (distancia = 1 - |corr|):

| etf | cluster |
| --- | --- |
| DRAM | 1 |
| EEM | 1 |
| EFA | 1 |
| HYG | 1 |
| IWM | 1 |
| QQQ | 1 |
| SOXX | 1 |
| SPY | 1 |
| XLE | 1 |
| XLF | 1 |
| XLK | 1 |
| XLP | 1 |
| DBC | 2 |
| USO | 2 |
| UUP | 2 |
| IEF | 3 |
| LQD | 3 |
| SGOV | 3 |
| TIP | 3 |
| TLT | 3 |
| GLD | 4 |
| XLU | 5 |

![dendrograma](images/dendrograma.png)

## 10. Red de correlación (umbral 0.6)

![red](images/red_correlacion.png)

## 11. Dependencia no lineal (información mutua)

La información mutua (en nats) detecta relaciones **no lineales** que la correlación de Pearson no ve. Compara con la matriz de correlación: pares con MI alta pero correlación baja son candidatos a relación no lineal.

| A | B | MI |
| --- | --- | --- |
| SPY | XLK | 0.255 |
| IEF | TIP | 0.251 |
| EFA | SPY | 0.244 |
| SPY | XLF | 0.196 |
| EEM | SPY | 0.160 |
| EFA | XLK | 0.150 |
| IWM | SPY | 0.145 |
| EFA | XLF | 0.134 |
| IEF | TLT | 0.130 |
| TIP | TLT | 0.126 |
| SOXX | XLK | 0.125 |
| IEF | LQD | 0.119 |
| QQQ | SPY | 0.117 |
| LQD | TIP | 0.116 |
| EEM | EFA | 0.116 |

## 12. Correlación en regímenes de estrés

Correlación con el benchmark (SPY) en los días malos (peor 10%) y buenos (mejor 10%). `asimetria` positiva = la correlación se dispara en las caídas (comportamiento típico de 'todo cae junto').

| etf | corr_all | corr_bad_days | corr_good_days | ret_bad_days_pct | ret_good_days_pct | asimetria |
| --- | --- | --- | --- | --- | --- | --- |
| XLP | 0.436 | 0.244 | 0.141 | -0.625 | 0.665 | 0.102 |
| QQQ | 0.471 | 0.220 | 0.156 | -0.995 | 1.066 | 0.064 |
| XLK | 0.655 | 0.381 | 0.319 | -1.882 | 2.191 | 0.062 |
| XLU | 0.274 | 0.134 | 0.081 | -0.535 | 0.428 | 0.052 |
| IEF | -0.151 | -0.092 | -0.132 | 0.124 | -0.168 | 0.041 |
| EEM | 0.546 | 0.258 | 0.224 | -1.326 | 1.345 | 0.034 |
| EFA | 0.651 | 0.400 | 0.366 | -1.417 | 1.374 | 0.034 |
| DRAM | 0.272 | 0.135 | 0.107 | -1.473 | 1.752 | 0.028 |
| LQD | 0.105 | -0.016 | -0.044 | -0.104 | 0.097 | 0.028 |
| GLD | -0.043 | 0.056 | 0.036 | 0.076 | -0.125 | 0.020 |
| HYG | 0.365 | 0.191 | 0.176 | -0.507 | 0.493 | 0.015 |
| XLE | 0.373 | 0.149 | 0.137 | -1.268 | 1.048 | 0.012 |
| SOXX | 0.431 | 0.169 | 0.166 | -1.845 | 2.134 | 0.003 |
| USO | 0.143 | 0.107 | 0.105 | -0.635 | 0.511 | 0.002 |
| TIP | -0.134 | -0.076 | -0.078 | 0.135 | -0.142 | 0.002 |
| SPY | 1.000 | 1.000 | 1.000 | -2.126 | 2.169 | 0.000 |
| TLT | -0.234 | -0.134 | -0.119 | 0.267 | -0.435 | -0.015 |
| SGOV | -0.004 | -0.029 | -0.013 | 0.012 | 0.009 | -0.017 |
| IWM | 0.517 | 0.222 | 0.255 | -1.150 | 1.056 | -0.033 |
| XLF | 0.597 | 0.362 | 0.398 | -1.486 | 1.471 | -0.036 |
| UUP | -0.107 | -0.130 | -0.080 | 0.168 | -0.084 | -0.050 |
| DBC | 0.191 | 0.053 | 0.111 | -0.577 | 0.401 | -0.058 |

**Drawdowns del benchmark (>10%)**

| inicio | fin | drawdown_max |
| --- | --- | --- |
| 2015-08-03 | 2015-08-06 | -0.115 |
| 2015-08-11 | 2015-08-28 | -0.134 |
| 2015-08-31 | 2015-09-10 | -0.132 |
| 2015-10-19 | 2015-10-22 | -0.112 |
| 2015-10-27 | 2015-11-02 | -0.113 |
| 2015-11-03 | 2015-11-05 | -0.104 |
| 2015-11-10 | 2015-11-13 | -0.104 |
| 2015-11-27 | 2015-12-15 | -0.138 |
| 2015-12-18 | 2015-12-21 | -0.107 |
| 2016-07-28 | 2016-08-04 | -0.127 |
| 2016-10-14 | 2016-10-17 | -0.103 |
| 2016-12-07 | 2016-12-12 | -0.124 |
| 2017-01-26 | 2017-02-14 | -0.135 |
| 2017-02-17 | 2017-03-22 | -0.145 |
| 2017-03-23 | 2017-04-05 | -0.139 |

## 13. Volatilidad y riesgo

| etf | ret_medio_diario_pct | vol_anualizada_pct | skew | kurtosis | sharpe_aproximado | n_obs | max_drawdown_pct |
| --- | --- | --- | --- | --- | --- | --- | --- |
| SPY | 0.048 | 19.395 | -0.054 | 0.109 | 0.625 | 3072 | -32.181 |
| QQQ | 0.052 | 19.744 | 0.013 | -0.110 | 0.665 | 3072 | -39.833 |
| IWM | 0.003 | 18.589 | -0.109 | -0.076 | 0.039 | 3072 | -63.102 |
| EFA | 0.020 | 19.098 | -0.071 | 0.141 | 0.267 | 3072 | -46.304 |
| EEM | 0.035 | 21.616 | 0.008 | 0.028 | 0.404 | 3072 | -50.406 |
| TLT | -0.035 | 14.221 | -0.041 | 0.020 | -0.617 | 3072 | -65.976 |
| IEF | -0.008 | 8.408 | 0.014 | 0.010 | -0.252 | 3072 | -42.785 |
| TIP | -0.000 | 8.276 | -0.059 | 0.218 | -0.015 | 3072 | -27.420 |
| SGOV | 0.011 | 0.748 | 0.068 | -0.073 | 3.727 | 3072 | -0.527 |
| LQD | 0.004 | 9.224 | 0.010 | 0.070 | 0.113 | 3072 | -25.191 |
| HYG | 0.001 | 12.446 | -0.058 | -0.122 | 0.018 | 3072 | -43.208 |
| UUP | 0.017 | 13.452 | 0.036 | 0.009 | 0.321 | 3072 | -38.229 |
| GLD | -0.017 | 16.982 | 0.076 | -0.007 | -0.255 | 3072 | -60.018 |
| USO | 0.048 | 36.313 | 0.031 | -0.098 | 0.332 | 3072 | -67.957 |
| DBC | 0.006 | 24.700 | 0.011 | -0.023 | 0.059 | 3072 | -69.879 |
| XLK | 0.066 | 28.188 | -0.020 | 0.043 | 0.594 | 3072 | -55.188 |
| XLF | -0.007 | 22.687 | -0.003 | 0.082 | -0.073 | 3072 | -63.844 |
| XLE | 0.037 | 28.479 | -0.063 | 0.093 | 0.329 | 3072 | -50.923 |
| XLU | -0.014 | 14.604 | 0.054 | 0.005 | -0.241 | 3072 | -71.019 |
| XLP | 0.005 | 13.532 | 0.113 | 0.003 | 0.089 | 3072 | -33.093 |
| SOXX | 0.066 | 41.063 | -0.047 | -0.102 | 0.405 | 3072 | -73.681 |
| DRAM | 0.066 | 56.061 | 0.018 | 0.074 | 0.296 | 3072 | -87.611 |

## Metodología y limitaciones

* Retornos logarítmicos diarios; correlación de Pearson (lineal) y Spearman (rangos).
* Ventanas: `max` = histórico completo, `ytd` = desde el 1 de enero, `3m`/`1m` = últimos 3 meses / 1 mes naturales.
* Ventanas cortas (1m ≈ 21 sesiones) tienen mucho ruido: úsalas como diagnóstico, no como verdad estructural.
* Granger ≠ causalidad real (puede haber variables omitidas).
* La cointegración mide equilibrio de largo plazo; el hedge ratio y la vida media se recalibran con el tiempo.
* Correlación no implica causalidad: dos ETFs pueden moverse juntos por un factor común (el mercado, los tipos, el dólar).
